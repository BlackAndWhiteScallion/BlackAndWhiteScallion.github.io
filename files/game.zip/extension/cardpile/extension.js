'use strict';
game.import('play',function(lib,game,ui,get,ai,_status){
	return {
		name:'cardpile',
		init:function(){
		},
		arenaReady:function(){
		},
	};
});
