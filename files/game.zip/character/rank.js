window.noname_character_rank={
    s:[
        "marisa"
    ],
    ap:[
        "suika", "lilyblack", "medicine", "yuuka", "komachi", "eiki", "aya", 
    ],
    a:[
        "hetate", "cirno", "daiyousei", "renko", "meribel", "zigui", "patchouli",  "youmu",  "mokou", "kanade", "shigure", "arisa", "yudachi", "megumin", "satone", "nero", "kurumi", "miku", "sinon", "scathach", "niuzhanshi", "mordred",
    ],
    am:[
        "actress", "bullygang", "yukizakura", "hemerocalliscitrinabaroni", "wingedtiger",
    ],
    bp:[
         "zither",  "pear", "rumia", "meiling", "koakuma",
    ],
    b:[
        "sakuya", "remilia", "flandre", "letty", "chen",
    ],
    bm:[
         "lilywhite", "lunasa", "merlin", "lyrica", "alice",
    ],
    c:[
        "yuyuko", "ran", "yukari", "wriggle", "mystia", "keine", 
    ],
    d:[
        "reimu", "tewi", "reisen", "eirin", "kaguya",
    ],
};
